package calculadora;

/**
 *
 * @author asael
 */
public class Calculadora {

    public static void main(String[] args) {
        CalcUI ui = new CalcUI();
        ui.setSize(455,370);
        ui.setVisible(true);
        ui.setResizable(false);
        ui.setLocationRelativeTo(null);
    }
    
}
